## How to install

pip install botipy

## Commands

botipy -h

- General usage guide

botipy start PROJECT_NAME 

- Build your discord.py bot project with the given name.