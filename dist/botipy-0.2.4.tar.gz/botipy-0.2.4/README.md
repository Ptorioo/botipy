## How to install

pip install botipy

## Commands